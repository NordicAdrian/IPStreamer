# IP Streamer


### 1 - Installation 

```
pip install git+https://github.com/NordicAdrian/IPStreamer.git
```